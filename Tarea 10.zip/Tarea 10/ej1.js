let parrafo = document.getElementById("parrafo");

parrafo.addEventListener("mouseover", (evento)=>{
    parrafo.classList.add("red");
});