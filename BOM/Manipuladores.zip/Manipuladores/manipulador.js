let answer = prompt("Ingresa el nombre del color que quieres que tenga el titulo: ");

const t = document.getElementById("titulo");

t.style.color = answer;
