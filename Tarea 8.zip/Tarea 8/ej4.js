let num1 = Number(prompt("Ingresa un número: "));
let num2 = Number(prompt("Ingresa un número: "));

console.log(Math.floor(Math.random() * (num2 - num1) + num1));