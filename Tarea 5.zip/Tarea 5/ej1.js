let listaNumeros = [
    23, 46, 79, 81, 97, 5, 21, 27, 5
];

let setNumeros = new Set(listaNumeros);

console.log(setNumeros);


