var num = Number(prompt("Ingresa el valor del producto: "));
        var iva = 0.21;
        var caliva = num * iva; 
        var result = num + caliva;

        alert("El total es :" + result);
