var num = Number(prompt("Introduce tu año de nacimiento"));

if ((2025 - num ) < 18){
    alert("Eres menor de edad");
} else {
    alert("Eres mayor de edad ");
}