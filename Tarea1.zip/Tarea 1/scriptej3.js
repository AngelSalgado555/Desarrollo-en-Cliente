var num = Number(prompt("Ingresa un número: "));
if (num%2 == 0){
    alert("El número introducido es par");
} else {
    alert("El número introducido es impar");
}