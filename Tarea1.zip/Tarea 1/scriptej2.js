var num = Number(prompt("Ingresa tres números: "));
var num2 = Number(prompt());
var num3 = Number(prompt());

var sum = num + num2 + num3; 
var result = sum/3; 

alert("El resultado es: " + result);