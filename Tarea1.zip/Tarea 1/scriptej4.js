var name = prompt("Introduce tres nombres: ");
var name2 = prompt();
var name3 = prompt();

if (name == name2 && name3){
    alert("Uno de los nombres introducido es igual a otro");
} else {
    alert("Ningun nombre es igual");
}