var dni = prompt("Ingresa los números de tu DNI: ");

var division = dni / 23; 
var numeroEntero = Math.trunc(division);
var multiplicacion = numeroEntero * 23;
var result = dni - multiplicacion; 

if (result == 0){
    alert("La letra T");
} else if (result == 1){
    alert("La letra R");
} else if (result == 2){
    alert("La letra W");
} else if (result == 3){
    alert("La letra A");
} else if (result == 4){
    alert("La letra G");
} else if (result == 5){
    alert("La letra M");
} else if (result == 6){
    alert("La letra Y");
} else if (result == 7){
    alert("La letra F");
} else if (result == 8){
    alert("La letra P");
} else if (result == 9){
    alert("La letra D");
} else if (result == 10){
    alert("La letra X");
} else if (result == 11){
    alert("La letra B");
} else if (result == 12){
    alert("La letra N");
} else if (result == 13){
    alert("La letra J");
} else if (result == 14){
    alert("La letra Z");
} else if (result == 15){
    alert("La letra S");
} else if (result == 16){
    alert("La letra Q");
} else if (result == 17){
    alert("La letra V");
} else if (result == 18){
    alert("La letra H");
} else if (result == 19){
    alert("La letra L");
} else if (result == 20){
    alert("La letra C");
} else if (result == 21){
    alert("La letra K");
} else if (result == 22){
    alert("La letra E");
} 
